BayesAss+ v 1.01 Mac OS X binary Instructions
Please note that this binary is not a console program. You will need to first place the file into your home directory (e.g., /Users/yourname/) and then open a terminal window and untar the files using a command like:
cd /Users/yourname; tar xzvf /Users/yourname/BayesAssP-OSX.tar.gz
This will create a directory named BayesAssO-OSX that contains the program file and an example input file called try.txt. To execute the program do:
cd /Users/yourname/BayesAss-OSX; ./BayesAssOSX
